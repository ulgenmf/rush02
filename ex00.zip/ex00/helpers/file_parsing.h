#ifndef FILE_PARSING_H
# define FILE_PARSING_H

# include "errors.h"
# include "helper_functions.h"

void	mf_putstr(char *str);
void	mf_putchar(char c);
int		mf_atoi(char *str);
char	*mf_strdup(char *src);
int		mf_strlen(char *str);
void	mf_strcpy(char *dst, char *src);


void create_ones(char * buffer){

}



void create_teens(char *buffer){

}


void get_power(char *buffer){

}



#endif